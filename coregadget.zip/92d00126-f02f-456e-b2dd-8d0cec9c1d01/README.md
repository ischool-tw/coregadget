gadget-EMBA學生個人資訊
==========================

* 身份「學生」
* 運用 coffee script 語法來撰寫
* 運用 less css 語法來撰寫 css
* 運用 gadget 物件呼叫 dsa 服務，依據呼叫不同類型的服務，來操做"修改"、"刪除"、"查詢"等功能
* 運用 twitter bootstrap 做為畫面設計的板型


功能說明
-------


--

****

